
<?php $__env->startSection('content'); ?>
        <!-- ***************************************************************************************** -->
    <!-- ***************************************************************************************** -->
    <section class="hero-slider">
        <div id="carouselExampleCaptions" class="carousel slide">
            <div class="carousel-indicators">
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="<?php echo e($loop->index); ?>"
                class="<?php echo e($loop->first ? 'active' : ''); ?>" aria-current="<?php echo e($loop->first ? 'true' : ''); ?>" aria-label="Slide 1"></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
            </div>
            <div class="carousel-inner">
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->index == 0 ? 'active' : ''); ?>">
                        <img src="<?php echo e(asset('userarea')); ?>/assets/main/bg.png" class="d-block w-100" alt="..." />
                        <div class="passport-img-box">
                            <img src="<?php echo e(asset($slide->image)); ?>" alt="passport" />
                        </div>
                        <div class="slider-text text-end">
                            <a href="<?php echo e($slide->link); ?>" style="text-decoration: none; <?php echo e(lang('en') ? 'text-align: start' : ''); ?>">
                                <h1><?php echo e($slide['title_'.lang()]); ?></h1>
                                <p><?php echo e($slide['desc_'.lang()]); ?></p>    
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </section>
    <!-- ***************************************************************************************** -->
    <!-- ***************************************************************************************** -->
    <div class="section-about text-center">
        <h2 class="heading--2"><?php echo e(__('dash.about_us')); ?></h2>
        <section class="about container">
            <div class="about-content-box">
                <p style="text-align: <?php echo e(lang('ar') ? 'right' : 'left'); ?>">
                    <?php echo setting('about_us_'.lang()); ?>

                </p>
            </div>
            <div class="about-img-box">
                <img src="<?php echo e(asset(setting('about_us_image'))); ?>" />
            </div>
        </section>
    </div>
    <!-- ***************************************************************************************** -->
    <!-- ***************************************************************************************** -->
    <section class="services">
        <h2 class="heading--2"><?php echo e(__('dash.categories')); ?></h2>

        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4 col-6">
                        <a style="text-decoration: none; color:black" href="<?php echo e(route('services', $category->id)); ?>">
                            <div class="service">
                                <div class="logo-img-box">
                                    <img src="<?php echo e(asset($category->image)); ?>" alt="" />
                                </div>
                                <p class="title" style="height: 35px;font-size: 1.5rem" ><?php echo e($category['title_'.lang()]); ?></p>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <a href="<?php echo e(route('categories')); ?>" class="more-link py-2"><?php echo e(__('dash.more')); ?></a>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('userarea.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alwaseetlinebh/public_html/resources/views/userarea/home.blade.php ENDPATH**/ ?>