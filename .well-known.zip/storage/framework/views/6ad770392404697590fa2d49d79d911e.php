<div>
    <section class="navigation-section short-nav d-flex justify-content-center align-items-center mb-0">
        <div class="text-center d-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('dash.home')); ?></a>
            <span><i style="font-size: medium; color: white;" class="fa-solid fa-angle-<?php echo e(lang('en') ? 'right': 'left'); ?> mx-5"></i></span>
            <a href="<?php echo e(route('categories')); ?>"><?php echo e(__('dash.categories')); ?></a>
            <span><i style="font-size: medium; color: white;" class="fa-solid fa-angle-<?php echo e(lang('en') ? 'right': 'left'); ?> mx-5"></i></span>
            <a href="contact.html"><?php echo e($category['title_' . lang()]); ?></a>
        </div>
    </section>

    <section class="info">
        <div class="container">
            <ul class="nav nav-pills mb-3 d-flex tab-menu" id="pills-tab" role="tablist">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button wire:click='serviceGet("<?php echo e($sub_category->id); ?>")' class="nav-link <?php echo e($selected_category_id == $sub_category->id ? 'active' : ''); ?> tab-item" id="pills-id-tab" data-bs-toggle="pill"
                        data-bs-target="#pills-id" type="button" role="tab" aria-controls="pills-id"
                        aria-selected="<?php echo e($selected_category_id == $sub_category->id); ?>">
                        <?php echo e($sub_category['title_'.lang()]); ?>

                    </button>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </ul>
            <div class="tab-content mt-5" id="pills-tabContent">
                <div class="tab-pane fade show active" id="pills-id" role="tabpanel" aria-labelledby="pills-id-tab"
                    tabindex="0">
                    <div class="row">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 tab-item-content">
                            <a class="id-item" href="<?php echo e(route('services_show', $service->id)); ?>">
                                <div class="info-content-box">
                                    <h4 style="height: 85px;"><?php echo e($service['title_'.lang()]); ?></h4>
                                    <p><?php echo e($service->category['title_'.lang()]); ?></p>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH /home/alwaseetlinebh/public_html/resources/views/livewire/userarea/service-f-live.blade.php ENDPATH**/ ?>