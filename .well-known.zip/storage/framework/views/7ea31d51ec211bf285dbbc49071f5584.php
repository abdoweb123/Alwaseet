<?php $__env->startSection('title'); ?>
    <?php if (isset($component)) { $__componentOriginal2346b0df6470764606bbfc809b6744cd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2346b0df6470764606bbfc809b6744cd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pageTitle','data' => ['current' => 'Home']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pageTitle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['current' => 'Home']); ?>
        <li class="breadcrumb-item active" aria-current="page">
            <?php echo e(__('dash.home')); ?>

        </li>
        <li class="breadcrumb-item" aria-current="page">
            <?php echo e(__('dash.orders')); ?>

        </li>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2346b0df6470764606bbfc809b6744cd)): ?>
<?php $attributes = $__attributesOriginal2346b0df6470764606bbfc809b6744cd; ?>
<?php unset($__attributesOriginal2346b0df6470764606bbfc809b6744cd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2346b0df6470764606bbfc809b6744cd)): ?>
<?php $component = $__componentOriginal2346b0df6470764606bbfc809b6744cd; ?>
<?php unset($__componentOriginal2346b0df6470764606bbfc809b6744cd); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class=" mx-auto row">
        <i role="button" onclick="CreatePDFfromHTML()" class="fa-solid fa-print"></i>


        <div style="font-size: 20px; font-weight: bold;" class="card border border-3 px-1  content-to-download mx-auto col-12 col-md-8 direction text-capitalize">
            <div class="card-body ">
                <div class="row mb-5" style="font-weight: 500;color: #2c2c6f;">

                    <div style="color: #2c2c6f !important; text-wrap:balance;"
                        class="col-5 text-dark fs-3 text-bold direction text-center pt-4 ">خط الوسيط لتخليص المعاملات</div>
                    <div class="col-2 text-dark fs-5 text-center"><img src="<?php echo e(setting('logo')); ?>"
                            style="width: 100px;height: 100px;"></div>
                    <div style="color: #2c2c6f !important;text-wrap:balance;"
                        class="col-5 text-dark fs-3 text-bold text-center pt-4">
                        Al-Waseet line documents clearance</div>
                </div>
                <table class="table text-center table-bordered">
                    <tbody style="font-weight: 500;">
                        <tr>
                            <td class="text-dark fs-5  direction ">تاريخ الانشاء </td>
                            <td><?php echo e($order->created_at->format('Y/m/d H:i a')); ?></td>
                            <td>created at</td>
                        </tr>
                        <?php if($order->order_number): ?>
                        <tr>
                            <td>رقم الفاتوره</td>
                            <td><?php echo e($order->order_number); ?></td>
                            <td>order number</td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td>الاسم</td>
                            <td><?php echo e($order->name); ?></td>
                            <td>@Name</td>
                        </tr>
                        <?php if($order->user?->cpr): ?>
                        <tr>
                            <td> رقم الهوية </td>
                            <td><?php echo e($order->user?->cpr); ?></td>
                            <td>CPR-CR</td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td>الهاتف </td>
                            <td><?php echo e($order->phone); ?></td>
                            <td>phone</td>
                        </tr>
                        <tr>
                            <td>الخدمة </td>
                            <td><?php echo e($order->service['title_' . lang()]); ?></td>
                            <td>Service</td>
                        </tr>
                        <tr>
                            <td>السعر</td>
                            <td><?php echo e($order->price); ?></td>
                            <td>Price</td>
                        </tr>
                        <?php if($order->bla_name): ?>
                        <tr>
                            <td>اسم صاحب المعاملة </td>
                            <td><?php echo e($order->bla_name); ?></td>
                            <td>Transaction owner name</td>
                        </tr>
                        <?php endif; ?>
                        <?php if($order->id_type): ?>
                        <tr>
                            <td>نوع الهوية </td>
                            <td><?php echo e($order->id_type); ?></td>
                            <td>ID Type</td>
                        </tr>
                        <?php endif; ?>
                        <?php if($order->id_number): ?>
                        <tr>
                            <td>رقم الهوية </td>
                            <td><?php echo e($order->id_number); ?></td>
                            <td>ID No.</td>
                        </tr>
                        <?php endif; ?>
                        <?php if($order->note): ?>
                        <tr>
                            <td>ملاحظات</td>
                            <td><?php echo e($order->note); ?></td>
                            <td>Notes</td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td>حالة الدفع </td>
                            <td> <?php echo e($order->status == 0 ? __('dash.waiting') : __('dash.done')); ?></td>
                            <td>Payment status</td>
                        </tr>
                        <?php if($order->user?->email): ?>
                        <tr>
                            <td>البريد الالكتروني</td>
                            <td><?php echo e($order->user?->email); ?></td>
                            <td>Email</td>
                        </tr>
                        <?php endif; ?>
                        <?php if($order->user?->phone): ?>
                        <tr>
                            <td>رقم الهاتف </td>
                            <td><?php echo e($order->user?->phone); ?></td>
                            <td>Phone</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
            <div class="card-footer text-muted fs-6">
                <div class="row">
                    <div class="col d-flex justify-content-center flex-column align-items-center">
                        <span><i class="fa-solid fa-mobile text-dark px-2"></i></span>
                        <span>
                            <a class="text-muted text-decoration-none" href="tel:37900700">
                                37900700
                            </a>
                        </span>
                    </div>
                    <div class="col d-flex justify-content-center flex-column align-items-center">
                        <span><i class="fa-solid fa-globe text-dark px-2"></i></span>
                        <a class="text-muted text-decoration-none" href="https://alwaseet-line-bh.com/">
                           Alwaseet-line-bh
                        </a>
                    </div>

                    <div class="col d-flex justify-content-center flex-column align-items-center">
                        <span><i class="fa-solid fa-envelope text-dark px-2"></i>
                        </span>
                        <span>
                            <a class="text-muted text-decoration-none" href="mailto:wldc.2024bh@gmail.com">
                                wldc.2024bh@gmail.com</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>

    <script>
        //Create PDf from HTML...
        function CreatePDFfromHTML() {
            var HTML_Width = $(".content-to-download").width();
            var HTML_Height = $(".content-to-download").height();
            var top_left_margin = 15;
            var PDF_Width = HTML_Width + (top_left_margin * 2);
            var PDF_Height = (PDF_Width * 1) + (top_left_margin * 2);
            var canvas_image_width = HTML_Width;
            var canvas_image_height = HTML_Height;

            var totalPDFPages = Math.ceil(HTML_Height / PDF_Height) - 1;

            html2canvas($(".content-to-download")[0]).then(function(canvas) {
                var imgData = canvas.toDataURL("image/jpeg", 1.0);
                var pdf = new jsPDF('p', 'pt', [PDF_Width, PDF_Height]);
                pdf.addImage(imgData, 'JPG', top_left_margin, top_left_margin, canvas_image_width,
                    canvas_image_height);
                for (var i = 1; i <= totalPDFPages; i++) {
                    pdf.addPage(PDF_Width, PDF_Height);
                    pdf.addImage(imgData, 'JPG', top_left_margin, -(PDF_Height * i) + (top_left_margin * 4),
                        canvas_image_width, canvas_image_height);
                }
                pdf.save("file.pdf");
                // $(".content-to-download").hide();
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alwaseetlinebh/public_html/resources/views/admin/show_order.blade.php ENDPATH**/ ?>