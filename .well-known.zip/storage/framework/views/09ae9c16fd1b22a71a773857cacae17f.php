<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(
    [
        'type' => 'text',
        'name',
        'label',
        'placeholder' => '',
        
    ]
) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(
    [
        'type' => 'text',
        'name',
        'label',
        'placeholder' => '',
        
    ]
); ?>
<?php foreach (array_filter((
    [
        'type' => 'text',
        'name',
        'label',
        'placeholder' => '',
        
    ]
), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class'=>'form-group mb-10'])); ?>>
    <label class="w-100" for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
    <input id="<?php echo e($name); ?>"  wire:model="<?php echo e($name); ?>" class="form-control" type="<?php echo e($type); ?>" placeholder="<?php echo e($placeholder); ?>">

    <!--[if BLOCK]><![endif]--><?php if($errors->has($name)): ?>
        <span class="text-danger"><?php echo e($errors->first($name)); ?></span>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH /home/alwaseetlinebh/public_html/resources/views/components/form/input.blade.php ENDPATH**/ ?>