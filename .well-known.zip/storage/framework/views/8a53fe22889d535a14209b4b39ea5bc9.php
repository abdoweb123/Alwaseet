

<?php $__env->startSection('content'); ?>
    <section class="navigation-section short-nav d-flex justify-content-center align-items-center mb-0">
        <div class="text-center d-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('dash.home')); ?></a>
            <span><i style="font-size: medium; color: white;"
                    class="fa-solid fa-angle-<?php echo e(lang('en') ? 'right' : 'left'); ?> mx-5"></i></span>
            <a href="contact.html"><?php echo e(__('dash.contact_us')); ?></a>
        </div>
    </section>
    <!-- ***************************************************************************************** -->
    <!-- ***************************************************************************************** -->
    <div class="contact-us-page-section container">
        <div class="flex-column-reverse flex-lg-row mt-5 row">
            <div class="col-lg-6">
                <h5 class="contact-heading"><?php echo e(__('dash.send_message')); ?></h5>
                <div class="contact-form-box">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success h3">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('contact_us_post')); ?>" method="POST" class="contact-form">
                        <?php echo csrf_field(); ?>
                        <div class="mb-5">
                            <label for="name" class="form-label mb-3"><?php echo e(__('dash.name')); ?></label>
                            <input type="text" name="name" class="form-control" />
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-5">
                            <label for="email" class="form-label mb-3"><?php echo e(__('dash.email')); ?></label>
                            <input type="email" name="email" class="form-control" required />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-5">
                            <label for="phone" class="form-label mb-3"><?php echo e(__('dash.phone')); ?></label>
                            <input type="number" name="phone" class="form-control" required />
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-5">
                            <label for="subject" class="form-label mb-3"><?php echo e(__('dash.subject')); ?></label>
                            <input type="text" name="subject" class="form-control" required />
                            <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-5">
                            <label for="message" class="form-label mb-3"><?php echo e(__('dash.message')); ?></label>
                            <textarea type="text" name="message" class="form-control" required></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="contact-us-btn btn btn-primary d-flex align-items-center"
                            style="font-size: 23px;">
                            <?php echo e(__('dash.send')); ?>

                        </button>
                    </form>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="contact-data-box">
                    <h5 class="contact-heading"><?php echo e(__('dash.contact_details')); ?></h5>
                    <div class="contact-data">
                        <span class="mx-3"><img src="<?php echo e(asset('userarea')); ?>/assets/main/contactPage/mail.svg"
                                alt="mail" />
                        </span>
                        <a href="mailTo:<?php echo e(setting('email')); ?>"><?php echo e(setting('email')); ?></a>
                    </div>
                    <div class="contact-data">
                        <span class="mx-3"><img src="<?php echo e(asset('userarea')); ?>/assets/main/contactPage/phone.svg"
                                alt="phone" />
                        </span>
                        <a target="_blank" href="https://wa.me/<?php echo e(setting('whatsapp')); ?>"><?php echo e(setting('whatsapp')); ?></a>
                    </div>
                    <div class="contact-data">
                        <span class="mx-3">
                            <img src="<?php echo e(asset('userarea')); ?>/assets/main/contactPage/location.svg" alt="location" />
                        </span>
                        <span><?php echo e(setting('address')); ?></span>
                    </div>
                    <div class="location-map">
                        <h5 class="contact-heading"><?php echo e(__('dash.google_location')); ?></h5>
                        <div class="location-img-box">
                            <iframe class="w-100"
                                src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d13649.280991210342!2d<?php echo e($points['long']); ?>!3d<?php echo e($points['lat']); ?>!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2seg!4v1703077461395!5m2!1sen!2seg"
                                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userarea.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alwaseetlinebh/public_html/resources/views/userarea/contact.blade.php ENDPATH**/ ?>