

<?php $__env->startSection('content'); ?>
    <section class="navigation-section short-nav d-flex justify-content-center align-items-center mb-0">
        <div class="text-center d-flex justify-content-center align-items-center">
            <a class="text-white" href="<?php echo e(route('home')); ?>"><?php echo e(__('dash.home')); ?></a>
            <span><i style="font-size: medium; color: white;" class="fa-solid fa-angle-<?php echo e(lang('en') ? 'right': 'left'); ?> mx-5"></i></span>
            <a href="services.html"><?php echo e(__('dash.categories')); ?></a>
        </div>
    </section>
    <!-- ***************************************************************************************** -->
    <!-- ***************************************************************************************** -->
    <section class="services services-page">
        <h2 class="heading--2"><?php echo e(__('dash.categories')); ?></h2>

        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4 col-6">
                        <div class="service information">
                            <a href="<?php echo e(route('services', $category->id)); ?>">
                                <div class="logo-img-box">
                                    <img src="<?php echo e(asset($category->image)); ?>" alt="" />
                                </div>
                                <p class="title" style="height: 35px;font-size: 1.5rem" ><?php echo e($category['title_'.lang()]); ?></p>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userarea.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alwaseetlinebh/public_html/resources/views/userarea/categories.blade.php ENDPATH**/ ?>