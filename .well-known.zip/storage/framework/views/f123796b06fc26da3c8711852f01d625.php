

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    <?php if (isset($component)) { $__componentOriginal2346b0df6470764606bbfc809b6744cd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2346b0df6470764606bbfc809b6744cd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pageTitle','data' => ['current' => 'Home']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pageTitle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['current' => 'Home']); ?>
        <li class="breadcrumb-item active" aria-current="page">
            <?php echo e(__('dash.home')); ?>

        </li>
        <li class="breadcrumb-item" aria-current="page">
            <?php echo e(__('dash.orders')); ?>

        </li>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2346b0df6470764606bbfc809b6744cd)): ?>
<?php $attributes = $__attributesOriginal2346b0df6470764606bbfc809b6744cd; ?>
<?php unset($__attributesOriginal2346b0df6470764606bbfc809b6744cd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2346b0df6470764606bbfc809b6744cd)): ?>
<?php $component = $__componentOriginal2346b0df6470764606bbfc809b6744cd; ?>
<?php unset($__componentOriginal2346b0df6470764606bbfc809b6744cd); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form method="POST" action="<?php echo e(route('dashboard.create_order')); ?>">
        <?php echo csrf_field(); ?>
        <div class="card-styles mt-4 row">
            <div class="form-group mt-10 col-12 col-md-6">
                <label class="w-100" for="user_id"><?php echo app('translator')->get('dash.cpr'); ?></label>
                <select class="form-control selectpicker" name="user_id" id="user_id">
                    <option value="">-----</option>
                    <?php $__currentLoopData = $users->sortBy('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($users->id); ?>"><?php echo e($users['cpr']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <div class="form-group mt-10 col-12 col-md-6">

                <label class="w-100" for="name"><?php echo app('translator')->get('dash.name'); ?></label>
                <input readonly id="name" name="name"  class="form-control" type="text">
            </div>
            <div class="form-group mt-10 col-12 col-md-6">
                <label class="w-100" for="phone"><?php echo app('translator')->get('dash.phone'); ?></label>
                <input readonly id="phone" name="phone"  class="form-control" type="text">
            </div>
            <div class="form-group mt-10 col-12 col-md-6">
                <label class="w-100" for="price"><?php echo app('translator')->get('dash.price'); ?></label>
                <input readonly id="price" name="price"  class="form-control" type="number" step="any" min="0">
            </div>
            <div class="form-group mt-10 col-12 col-md-6">
                <label class="w-100" for="service_id"><?php echo app('translator')->get('dash.service'); ?></label>
                <select class="form-control selectpicker" name="service_id" id="service_id">
                    <?php $__currentLoopData = $services->sortBy('title_'.app()->getlocale()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($service->id); ?>"><?php echo e($service['title_'.app()->getlocale()]); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <div class="form-group mt-10 col-12">
                <button type="submit" style="width: 200px;" class="btn btn-info"><?php echo app('translator')->get('dash.submit'); ?></button>
            </div>
            
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    
    <script>
        $(document).ready(function() {
            $(".selectpicker").select2({
                language: "<?php echo e(lang()); ?>",
                dir: "<?php echo e(lang('ar') ? 'rtl' : 'ltr'); ?>",
                closeOnSelect: false,
            });
        });
    </script>
<script>
    $(document).ready(function() {
        $('#user_id').change(function() {
            var userId = $(this).val();
            if (userId) {
                $.ajax({
                    url: "<?php echo e(route('dashboard.user_data')); ?>",
                    type: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        user_id: userId
                    },
                    success: function(data) {
                        $('#name').val(data.name);
                        $('#phone').val(data.phone);
                    },
                    error: function() {
                        alert('Failed to fetch user data.');
                    }
                });
            } else {
                $('#name').val('');
                $('#phone').val('');
            }
        });
    });
</script>
<script>
    $(document).ready(function() {
        $('#service_id').change(function() {
            var service_id = $(this).val();
            var user_id=$('#user_id').val();
            if (service_id && user_id) {
                $.ajax({
                    url: "<?php echo e(route('dashboard.service_price')); ?>",
                    type: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        service_id: service_id,
                        user_id:user_id
                    },
                    success: function(data) {
                        $('#price').val(data);
                    },
                    error: function() {
                        alert('Failed to fetch user data.');
                    }
                });
            } else {
                $('#price').val('');
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alwaseetlinebh/public_html/resources/views/admin/new_order.blade.php ENDPATH**/ ?>