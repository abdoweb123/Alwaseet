<?php $__env->startSection('content'); ?>
    <section class="navigation-section d-flex justify-content-center align-items-center">
        <div class="text-center d-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('dash.home')); ?></a>
            <span><i style="font-size: medium; color: white;"
                    class="fa-solid fa-angle-<?php echo e(lang('en') ? 'right' : 'left'); ?> mx-5"></i></span>
            <a href="<?php echo e(route('categories')); ?>"><?php echo e(__('dash.categories')); ?></a>
            <span><i style="font-size: medium; color: white;"
                    class="fa-solid fa-angle-<?php echo e(lang('en') ? 'right' : 'left'); ?> mx-5"></i></span>
            <a href="<?php echo e(route('services', $category->category->id)); ?>"><?php echo e($category->category['title_' . lang()]); ?></a>
            <span><i style="font-size: medium; color: white;"
                    class="fa-solid fa-angle-<?php echo e(lang('en') ? 'right' : 'left'); ?> mx-5"></i></span>
            <a href="contact.html"><?php echo e($category['title_' . lang()]); ?></a>
        </div>

        <div class="ministry-logo-box">
            <img src="<?php echo e(asset($category->category->image)); ?>" alt="" />
        </div>
    </section>
    <!-- ***************************************************************************************** -->
    <!-- ***************************************************************************************** -->
    <section class="id-service-details">
        <div class="container outer-container">
            <div class="content-container w-100">
                <div class="id-title">
                    <p><?php echo e($service['title_' . lang()]); ?></p>
                    <p class="price"><?php echo e(__('dash.service_cost')); ?>: <span dir="ltr">BHD
                            <?php if(auth()->check()): ?>
                                <?php if(auth()->user()->total_price_month != null && \Carbon\Carbon::now()->toDateString()  < auth()->user()->end_memebership): ?>
                                    <?php echo e($service->price_for_users); ?>


                                <?php else: ?>
                                    <?php echo e($service->price); ?>

                                <?php endif; ?>
                            <?php else: ?>
                                <?php echo e($service->price); ?>

                            <?php endif; ?>
                        </span></p>
                </div>
                <h5 class="government"><?php echo e($category->category['title_' . lang()]); ?></h5>
                <h5 class="py-2"><?php echo e(__('dash.service_details')); ?></h5>
                <p class="id-text"><?php echo e($service['desc_' . lang()]); ?></p>
                <?php if(auth()->check()): ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success h3">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php elseif(session('error')): ?>
                        <div class="alert alert-danger h3">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php else: ?>
                        <form action="<?php echo e(route('user_store', $service->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="contact-us-btn mx-auto w-50"><?php echo e(__('dash.contact_with_us')); ?></button>
                        </form>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(route('guest', $service->id)); ?>"
                        class="contact-us-btn mx-auto w-50"><?php echo e(__('dash.contact_with_us')); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userarea.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alwaseetlinebh/public_html/resources/views/userarea/service_show.blade.php ENDPATH**/ ?>