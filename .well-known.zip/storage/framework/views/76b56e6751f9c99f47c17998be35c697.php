
<div class="card-styles mt-4">
    <input wire:model.live='search' type="text" style="width: 30%;" class="form-control w-20"
        placeholder="<?php echo e(__('dash.searchOrder')); ?> ..">
    <div class="table-wrapper table-responsive">
        <table class="table clients-table">
            <thead>
                <tr>
                    <th><?php echo e(__('dash.order_number')); ?></th>
                    <th><?php echo e(__('dash.created_at')); ?></th>
                    <th><?php echo e(__('dash.name')); ?></th>
                    <th><?php echo e(__('dash.phone')); ?></th>
                    <th><?php echo e(__('dash.service')); ?></th>
                    <th><?php echo e(__('dash.price')); ?></th>
                    <th><?php echo e(__('dash.end_membership')); ?></th>
                    <th><?php echo e(__('dash.request_status')); ?></th>
                    <th><?php echo e(__('dash.status')); ?></th>
                    <th><?php echo e(__('dash.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td><?php echo e($order->order_number); ?></td>
                        <td><?php echo e($order->created_at->format('Y/m/d H:i a')); ?></td>
                        <td><?php echo e($order->name); ?></td>
                        <td><?php echo e($order->phone); ?></td>
                        <td><?php echo e($order->service['title_' . lang()]); ?></td>
                        <td><?php echo e($order->price); ?></td>
                        <td><?php echo e($order->user?->end_memebership ?? __('dash.noend')); ?></td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($order->request_status == 0): ?>
                                <span wire:click="openChangeRequestStatusModal(<?php echo e($order->id); ?>)" type="button"
                                    data-bs-toggle="modal" data-bs-target="#changestatus" class="bg-info-100 px-4 py-2 rounded-5 rounded-full shadow-sm">
                                    <i class="fa-regular fa-clock"></i>
                                    <?php echo e(__('dash.request_proccessing')); ?>

                                </span>
                            <?php elseif($order->request_status == 1): ?>
                                <span wire:click="openChangeRequestStatusModal(<?php echo e($order->id); ?>)" type="button"
                                    data-bs-toggle="modal" data-bs-target="#changestatus" class="bg-info-600 px-4 py-2 rounded-5 rounded-full">
                                    <i class="fa-solid fa-check"></i>
                                    <?php echo e(__('dash.request_done')); ?>

                                </span>
                            <?php else: ?>
                                <span wire:click="openChangeRequestStatusModal(<?php echo e($order->id); ?>)" type="button"
                                    data-bs-toggle="modal" data-bs-target="#changestatus" class="text-white bg-danger px-4 py-2 rounded-5 rounded-full">
                                    <i class="fa-solid fa-cancel"></i>
                                    <?php echo e(__('dash.request_cancelled')); ?>

                                </span>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($order->status == false): ?>
                                <span role="button" wire:click='changeStatus(<?php echo e($order->id); ?>)'
                                    class="bg-info-100 px-4 py-2 rounded-5 rounded-full shadow-sm">
                                    <i class="fa-regular fa-clock"></i>
                                    <?php echo e(__('dash.waiting')); ?>

                                </span>
                            <?php else: ?>
                                <span role="button" wire:click='changeStatus(<?php echo e($order->id); ?>)'
                                    class="bg-info-600 px-4 py-2 rounded-5 rounded-full">
                                    <i class="fa-solid fa-check"></i>
                                    <?php echo e(__('dash.done')); ?>

                                </span>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td>
                            <a wire:click="openDeleteModal(<?php echo e($order->id); ?>)" type="button" data-bs-toggle="modal"
                                data-bs-target="#deleteModal">
                                <i class="text-danger lni lni-trash-can"></i>
                            </a>
                            <a href="<?php echo e(route('dashboard.order_show', $order->id)); ?>" type="button">
                                <i class="text-info lni lni-eye mr-10"></i>
                            </a>
                            <a wire:click="openEditModal(<?php echo e($order->id); ?>)" type="button" data-bs-toggle="modal"
                                data-bs-target="#editModal">
                                <i class="text-primary lni lni-pencil mr-10"></i>
                            </a>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </tbody>
            <?php echo e($orders->links()); ?>

        </table>
        <div class="container ">
            <div class="row">
                <div class="col-6">
                    <h4 class="p-2  bg-info-600 text-black">
                        <!-- Your content for the left side -->

                        <?php echo e(__('dash.total')); ?> : <?php echo e($sumPrice); ?>



                    </h4>
                </div>
                <div class="col-6">
                    <h4 class="p-2  bg-info-600 text-black">
                        <!-- Your content for the left side -->

                        <?php echo e(__('dash.numberofOrders')); ?> : <?php echo e($ordersCount); ?>



                    </h4>

                </div>
            </div>
        </div>
    </div>

    
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['wireAction' => 'delete','id' => 'deleteModal','title' => ''.e(__('dash.delete')).'','type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wireAction' => 'delete','id' => 'deleteModal','title' => ''.e(__('dash.delete')).'','type' => 'danger']); ?>
        <div class="row">
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'warning']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'warning']); ?>
                <h3><?php echo e(__('dash.alert_delete_confirm')); ?></h3>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['wireAction' => 'update','id' => 'editModal','title' => ''.e(__('dash.update')).'','type' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wireAction' => 'update','id' => 'editModal','title' => ''.e(__('dash.update')).'','type' => 'info']); ?>
        <div class="row">
            <div class="form-group mb-10">
                <label class="w-100" for="order_number"><?php echo e(__('dash.order_number')); ?></label>
                <input id="order_number" wire:model="order_number" class="form-control ">
                <!--[if BLOCK]><![endif]--><?php if($errors->has('order_number')): ?>
                    <span class="text-danger"><?php echo e($errors->first('order_number')); ?></span>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
            <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['name' => 'bla_name','label' => ''.e(__('dash.bla_name')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bla_name','label' => ''.e(__('dash.bla_name')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['name' => 'id_type','label' => ''.e(__('dash.id_type')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'id_type','label' => ''.e(__('dash.id_type')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['name' => 'id_number','label' => ''.e(__('dash.id_number')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'id_number','label' => ''.e(__('dash.id_number')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $attributes = $__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__attributesOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b)): ?>
<?php $component = $__componentOriginal5c2a97ab476b69c1189ee85d1a95204b; ?>
<?php unset($__componentOriginal5c2a97ab476b69c1189ee85d1a95204b); ?>
<?php endif; ?>

            
            <?php if (isset($component)) { $__componentOriginal1f4c37f223521fbab853121650502055 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f4c37f223521fbab853121650502055 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.regtextarea','data' => ['label' => ''.e(__('dash.notes')).'','name' => 'note']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.regtextarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('dash.notes')).'','name' => 'note']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f4c37f223521fbab853121650502055)): ?>
<?php $attributes = $__attributesOriginal1f4c37f223521fbab853121650502055; ?>
<?php unset($__attributesOriginal1f4c37f223521fbab853121650502055); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f4c37f223521fbab853121650502055)): ?>
<?php $component = $__componentOriginal1f4c37f223521fbab853121650502055; ?>
<?php unset($__componentOriginal1f4c37f223521fbab853121650502055); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['wireAction' => 'updateStatus','id' => 'changestatus','title' => ''.e(__('dash.chngeStatus')).'','type' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wireAction' => 'updateStatus','id' => 'changestatus','title' => ''.e(__('dash.chngeStatus')).'','type' => 'info']); ?>
        <div class="row">

            <div class="form-group mb-10">
                <label class="w-100" for="request_status"><?php echo e(__('dash.request_status')); ?></label>

                <select wire:model="request_status" name="request_status" id="request_status" class="form-control">
                    <option hidden>--</option>
                    <option <?php if($order->request_status == 0): ?> selected <?php endif; ?> value="0">
                        <?php echo e(__('dash.request_proccessing')); ?></option>
                    <option <?php if($order->request_status == 1): ?> selected <?php endif; ?> value="1">
                        <?php echo e(__('dash.request_done')); ?></option>
                    <option <?php if($order->request_status == 2): ?> selected <?php endif; ?> value="2">
                        <?php echo e(__('dash.request_cancelled')); ?></option>
                </select>
                <!--[if BLOCK]><![endif]--><?php if($errors->has('request_status')): ?>
                    <span class="text-danger"><?php echo e($errors->first('request_status')); ?></span>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>

        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
</div>

<?php $__env->startSection('js'); ?>
    <?php if (isset($component)) { $__componentOriginal44a3e282bfe5328496fe85aa27e55030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal44a3e282bfe5328496fe85aa27e55030 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.closeModal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('closeModal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal44a3e282bfe5328496fe85aa27e55030)): ?>
<?php $attributes = $__attributesOriginal44a3e282bfe5328496fe85aa27e55030; ?>
<?php unset($__attributesOriginal44a3e282bfe5328496fe85aa27e55030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal44a3e282bfe5328496fe85aa27e55030)): ?>
<?php $component = $__componentOriginal44a3e282bfe5328496fe85aa27e55030; ?>
<?php unset($__componentOriginal44a3e282bfe5328496fe85aa27e55030); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/alwaseetlinebh/public_html/resources/views/livewire/dashboard/order-live.blade.php ENDPATH**/ ?>