<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(
    [
        'routeName' => 'text',
        'title',
        'icon',
    ]
) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(
    [
        'routeName' => 'text',
        'title',
        'icon',
    ]
); ?>
<?php foreach (array_filter((
    [
        'routeName' => 'text',
        'title',
        'icon',
    ]
), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<li class="nav-item <?php if(str_contains(Route::currentRouteName(), $routeName)): ?> active <?php endif; ?>">
        <a href="<?php echo e(route($routeName)); ?>">
        <span class="icon text-center">
            <i style="width: 20px;" class="<?php echo e($icon); ?> mx-2"></i>
        </span>
        <span class="text"><?php echo e($title); ?></span>
    </a>
</li>
<?php /**PATH /home/alwaseetlinebh/public_html/resources/views/components/nav-item.blade.php ENDPATH**/ ?>