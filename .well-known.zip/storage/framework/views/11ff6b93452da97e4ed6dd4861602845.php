
<?php $__env->startSection('content'); ?>
    <section class="signUp-logIn container">
        <div class="row mt-5">
            <div class="col-lg-6">
                <ul class="nav nav-pills sign-up-pills mb-3" id="pills-tab" role="tablist">
                    
                    <li class="nav-item active login-in-tab" role="presentation">
                        <button class="nav-link active sign-nav-item" id="pills-login-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-login" type="button" role="tab" aria-controls="pills-login"
                            aria-selected="false"
                            >
                            <?php echo e(__('dash.login')); ?>

                        </button>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade " id="pills-signUp" role="tabpanel"
                        aria-labelledby="pills-signUp-tab" tabindex="0">
                        
                    </div>
                    <div class="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="pills-login-tab"
                        tabindex="0">
                        <div class="login-form-box">
                            <?php if(session('error')): ?>
                                <div class="alert alert-danger h3">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>    
                            <form action="<?php echo e(route('login')); ?>" method="post" class="login-form">
                                <?php echo csrf_field(); ?>
                  
                                <div class="mb-5  ">
                                    <label for="cpr" class="form-label"><?php echo e(__('dash.cpr')); ?></label>
                                    <input dir="<?php echo e(lang('ar') ? 'rtl' : 'ltr'); ?>" autocomplete="off" name="cpr" type="text" id="cpr" class="form-control" required />
                                    
                                    <?php $__errorArgs = ['cpr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                    
                                </div>

                                <div class="mb-5">
                                    <label for="password" class="form-label"><?php echo e(__('dash.password')); ?></label>
                                    <input  name="password" type="password" class="form-control" required />
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                    
                                </div>
                                <button type="submit"
                                    class="contact-us-btn btn btn-log-in btn-primary d-flex align-items-center"style="font-size: 23px;">
                                    <?php echo e(__('dash.login')); ?>

                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="signup-img-box">
                    <img src="<?php echo e(asset('userarea')); ?>/assets/main/signupPage/AdobeStock_328703928.png" alt="" />
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userarea.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alwaseetlinebh/public_html/resources/views/userarea/login.blade.php ENDPATH**/ ?>