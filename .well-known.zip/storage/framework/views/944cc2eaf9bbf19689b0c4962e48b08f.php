<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'size' => '',
    'id',
    'title',
    'type',
    'btnName' => __('dash.confirm'),
    'wireAction' => false,
    'submit' => false,
    'addNew' => false,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'size' => '',
    'id',
    'title',
    'type',
    'btnName' => __('dash.confirm'),
    'wireAction' => false,
    'submit' => false,
    'addNew' => false,
]); ?>
<?php foreach (array_filter(([
    'size' => '',
    'id',
    'title',
    'type',
    'btnName' => __('dash.confirm'),
    'wireAction' => false,
    'submit' => false,
    'addNew' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div wire:ignore.self wire:loading.attr='disabled' class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" aria-labelledby="<?php echo e($id); ?>"
    aria-hidden="true">
    <div class="modal-dialog <?php echo e($size); ?>">
        <div class="modal-content">
            <div class="modal-header d-block modal-header">
                <button type="button" class="bg-warning btn-close float-start mt-0" data-bs-dismiss="modal" aria-label="Close"></button>
                <h1 class="float-end fs-5 modal-title" id="detailsModal"><?php echo e($title); ?></h1>
            </div>
            <div class="modal-body">
                <?php echo e($slot); ?>

            </div>
            <!--[if BLOCK]><![endif]--><?php if($wireAction): ?>
            <div class="modal-footer">
                <button wire:click='<?php echo e($wireAction); ?>' type="button" class="btn btn-<?php echo e($type); ?>" wire:loading.attr='disabled'><?php echo e($btnName); ?></button>
                <!--[if BLOCK]><![endif]--><?php if($addNew): ?>
                    <button wire:click='<?php echo e($wireAction); ?>("true")' type="button" class="btn btn-dark" wire:loading.attr='disabled'><?php echo e($btnName); ?> <?php echo e(__('dash.add_new')); ?></button>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div>
<?php /**PATH /home/alwaseetlinebh/public_html/resources/views/components/modal.blade.php ENDPATH**/ ?>