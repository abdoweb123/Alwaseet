<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'active' => false,
    'title',
    'route' => null
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'active' => false,
    'title',
    'route' => null
]); ?>
<?php foreach (array_filter(([
    'active' => false,
    'title',
    'route' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

    <!--[if BLOCK]><![endif]--><?php if($active): ?>
        <li class="breadcrumb-item active text-bold text-black" aria-current="page">
            <?php echo e($title); ?>

        </li>
    <?php else: ?>
        <li class="breadcrumb-item" aria-current="page">
            <a wire:navigate href="<?php echo e($route); ?>">
                <?php echo e($title); ?>

            </a>
        </li>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
<?php /**PATH /home/alwaseetlinebh/public_html/resources/views/components/breadcrumb.blade.php ENDPATH**/ ?>