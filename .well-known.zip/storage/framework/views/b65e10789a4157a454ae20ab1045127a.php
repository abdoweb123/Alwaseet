

<?php $__env->startSection('content'); ?>
    <section class="navigation-section d-flex justify-content-center align-items-center">
        <div class="text-center d-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('dash.home')); ?></a>
            <span><i style="font-size: medium; color: white;" class="fa-solid fa-angle-<?php echo e(lang('en') ? 'right': 'left'); ?> mx-5"></i></span>
            <a href="<?php echo e(route('categories')); ?>"><?php echo e(__('dash.categories')); ?></a>
            <span><i style="font-size: medium; color: white;" class="fa-solid fa-angle-<?php echo e(lang('en') ? 'right': 'left'); ?> mx-5"></i></span>
            <a href="<?php echo e(route('services', $category->category->id)); ?>"><?php echo e($category->category['title_' . lang()]); ?></a>
            <span><i style="font-size: medium; color: white;" class="fa-solid fa-angle-<?php echo e(lang('en') ? 'right': 'left'); ?> mx-5"></i></span>
            <a href="contact.html"><?php echo e($category['title_' . lang()]); ?></a>
        </div>

        <div class="ministry-logo-box">
            <img src="<?php echo e(asset($category->category->image)); ?>" alt="" />
        </div>
    </section>

    <section class="id-service-details">
        <div class="container outer-container">
            <div class="content-container">
                <?php if(session('success')): ?>
                    <div class="alert alert-success h3">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('guest_store')); ?>" method="post" class="send-request-form">
                    <?php echo csrf_field(); ?>
                    <div class="mb-5">
                        <label for="name" class="form-label"> <?php echo e(__('dash.name')); ?></label>
                        <input name="name" type="text" class="form-control" />
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-5">
                        <label for="phone" class="form-label"><?php echo e(__('dash.phone')); ?></label>
                        <input name="phone" type="number" class="form-control" />
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <input type="hidden" name="service_id", value="<?php echo e($service->id); ?>">
                    <button type="submit" class="contact-us-btn btn btn-primary d-flex align-items-center">
                        <?php echo e(__('dash.send')); ?>

                    </button>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userarea.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alwaseetlinebh/public_html/resources/views/userarea/guest.blade.php ENDPATH**/ ?>