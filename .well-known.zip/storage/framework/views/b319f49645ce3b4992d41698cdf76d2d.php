
<?php $__env->startSection('content'); ?>
    <div class="container edit-section">
        <a href="<?php echo e(route('profile')); ?>">
            <h5 class="edit-heading mx-2 text-dark px-4"><?php echo e(__('dash.edit_profile')); ?></h5>
        </a>
        <h5 class="edit-heading mx-2 bg-body-secondary p-4 rounded-5"><?php echo e(__('dash.old_orders')); ?></h5>

        <h5 role="button" onclick="document.getElementById('logout_form').submit();" class="edit-heading mx-2 px-4">
            <?php echo e(__('dash.logout')); ?></h5>
        <form id="logout_form" action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
        </form>
        <div class="edit-form-box mt-5">
            <div class="tab-item-content row gap-5">
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-12 mx-auto w-75">
                        <div class="info-content-box row">
                            <div class="col-12">
                                <h4><?php echo e($order->service['title_' . lang()]); ?></h4>
                                <p><?php echo e($order->service->category->category['title_' . lang()]); ?>

                                    (<?php echo e($order->service->category['title_' . lang()]); ?>)</p>
                                <p><?php echo e($order->created_at->diffForHumans()); ?></p>
                                <p><?php echo e($order->order_number); ?></p>
                                <br>
                                <?php if($order->status == false): ?>
                                    <span class="bg-secondary-subtle d-flex p-2 px-4 rounded-5 w-25" style="font-size: 15px;">
                                        <i class="fa-regular fa-clock"></i>
                                        <?php echo e(__('dash.waiting')); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="bg-success-subtle d-flex p-2 px-4 rounded-5 w-25" style="font-size: 15px;">
                                        <i class="fa-solid fa-check"></i>
                                        <?php echo e(__('dash.done')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>    
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h4>
                   <?php echo e(__('dash.nodata')); ?>

                </h4>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userarea.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alwaseetlinebh/public_html/resources/views/userarea/old_orders.blade.php ENDPATH**/ ?>