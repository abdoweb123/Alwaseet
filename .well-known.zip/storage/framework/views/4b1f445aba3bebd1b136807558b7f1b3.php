<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<meta name="robots" content="max-snippet:-1,max-image-preview:large,max-video-preview:-1">
<meta name="author" content="Kayak Time - for Boat Rental">
<meta name="image" content="<?php echo e(asset('userarea/img/logo.svg')); ?>">
<meta property="og:title" content="<?php echo e(setting('title')); ?>">
<meta property="og:description" content="<?php echo e(strip_tags(setting('desc'))); ?>">
<meta property="og:locale" content="en">
<meta property="og:image" content="<?php echo e(asset('userarea/img/logo.svg')); ?>">
<meta property="og:url" content="<?php echo e(url()->full()); ?>">
<meta property="og:site_name" content="<?php echo e(setting('title')); ?>">
<meta property="og:type" content="website">
<meta name="twitter:card" content="<?php echo e(setting('title')); ?>">
<meta name="twitter:title" content="<?php echo e(setting('title')); ?>">
<meta name="twitter:description" content="<?php echo e(strip_tags(setting('desc'))); ?>">
<meta name="twitter:site" content="<?php echo e(setting('title')); ?>">
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
<link rel="manifest" href="/favicon/site.webmanifest">

<link rel="canonical" href="<?php echo e(url()->full()); ?>">
<link rel="sitemap" href="/sitemap.xml" title="Sitemap" type="application/xml">
<link href="<?php echo e(asset('userarea/images/logo.png')); ?>" rel="shortcut icon">

<?php echo setting('snapchat_services'); ?>

<?php echo setting('twitter_services'); ?>

<?php echo setting('facebbok_services'); ?>

<?php echo setting('google_services'); ?>

<?php echo setting('tiktok_services'); ?>

<?php echo setting('instagram_services'); ?>

<?php /**PATH /home/alwaseetlinebh/public_html/resources/views/userarea/inc/seo.blade.php ENDPATH**/ ?>