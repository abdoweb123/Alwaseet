

<?php $__env->startSection('content'); ?>
    <section class="navigation-section short-nav d-flex justify-content-center align-items-center mb-0">
        <div class="text-center d-flex justify-content-center align-items-center">
            <a class="text-white" href="<?php echo e(route('home')); ?>"><?php echo e(__('dash.home')); ?></a>
            <span><i style="font-size: medium; color: white;" class="fa-solid fa-angle-<?php echo e(lang('en') ? 'right': 'left'); ?> mx-5"></i></span>
                    <a href="about.html"><?php echo e(__('dash.about_us')); ?></a>
        </div>
    </section>
    <!-- ***************************************************************************************** -->
    <!-- ***************************************************************************************** -->
    <div class="about-us-page-section">
        <h3 class="container about-heading"><?php echo e(__('dash.about_us')); ?></h3>
        <section class="about container">
            <div class="about-content-box">
                <p style="text-align: <?php echo e(lang('ar') ? 'right' : 'left'); ?>">
                  <?php echo setting('about_us_'.lang()); ?>

                </p>
            </div>
            <div class="about-img-box">
              <img src="<?php echo e(asset(setting('about_us_image'))); ?>" />
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userarea.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alwaseetlinebh/public_html/resources/views/userarea/about.blade.php ENDPATH**/ ?>