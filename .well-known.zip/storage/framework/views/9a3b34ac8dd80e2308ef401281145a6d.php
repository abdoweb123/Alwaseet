<?php $__env->startSection('content'); ?>
    <div class="container edit-section">
        <h5 class="edit-heading mx-2 bg-body-secondary edit-heading mx-2 p-4 rounded-5"><?php echo e(__('dash.edit_profile')); ?></h5>
        <a href="<?php echo e(route('old_orders')); ?>">
            <h5 class="edit-heading mx-2 text-dark px-4"><?php echo e(__('dash.old_orders')); ?></h5>
        </a>
        <h5 role="button" onclick="document.getElementById('logout_form').submit();" class="edit-heading mx-2 px-4">
            <?php echo e(__('dash.logout')); ?></h5>
        <h5 class="edit-heading mx-2 px-4"><?php echo e(__('dash.wallet')); ?> : <?php echo e($user->wallet); ?></h5>
        <form id="logout_form" action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
        </form>
        <div class="edit-form-box mt-5">
            <?php if(session('error')): ?>
                <div class="alert alert-danger h3">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <div class="alert alert-success h3">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('change_pass')); ?>" class="edit-form">
                <?php echo csrf_field(); ?>
                <div class="mb-5">
                    <label for="name" class="form-label"><?php echo e(__('dash.name')); ?></label>
                    <input name="name" type="text" value="<?php echo e($user->name); ?>" class="form-control" required />
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-5">
                    <label for="email" class="form-label"><?php echo e(__('dash.email')); ?></label>
                    <input name="email" type="text" value="<?php echo e($user->email); ?>" class="form-control" required />
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-5">
                    <label for="phone" class="form-label"><?php echo e(__('dash.phone')); ?></label>
                    <input name="phone" type="text" value="<?php echo e($user->phone); ?>" class="form-control" required />
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-5">
                    <label for="password" class="form-label"><?php echo e(__('dash.password')); ?></label>
                    <input autocomplete="false" type="password" id="password" name="password" class="form-control iti" />
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php if(
                    $user->number_months != null &&
                        $user->end_memebership != null &&
                        $user->price_month != null &&
                        $user->total_price_month != null): ?>
                    <div class="mb-5">
                        <label for="number_months" class="form-label"><?php echo e(__('dash.number_months')); ?></label>
                        <input readonly value="<?php echo e($user->number_months); ?>" autocomplete="false" type="number"
                            id="number_months" name="number_months" class="form-control iti" />
                        <?php $__errorArgs = ['number_months'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-5">
                        <label for="end_memebership" class="form-label"><?php echo e(__('dash.end_memebership')); ?></label>
                        <input readonly value="<?php echo e(\Carbon\Carbon::parse($user->end_memebership)->format('d/m/Y')); ?>" autocomplete="false" type="text"
                            id="end_memebership" name="end_memebership" class="form-control iti" />
                        <?php $__errorArgs = ['end_memebership'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-5">
                        <label for="price_month" class="form-label"><?php echo e(__('dash.price_month')); ?></label>
                        <input readonly value="<?php echo e($user->price_month); ?>" autocomplete="false" type="number"
                            id="price_month" name="price_month" class="form-control iti" />
                        <?php $__errorArgs = ['price_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="alert text-danger" style="font-size: medium;"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(\Carbon\Carbon::now()->toDateString() >= $user->end_memebership): ?>
                        <h2 class="alert-heading alert alert-danger">
                            <?php echo e(__('dash.membership_expired')); ?>

                        </h2>

                        <a href="<?php echo e(url('contact_us')); ?>"
                            class="contact-us-btn btn btn-save btn-primary d-flex align-items-center"
                            style="font-size: 28px;">
                            <?php echo e(__('dash.editmembership')); ?>

                        </a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(url('contact_us')); ?>"
                        class="contact-us-btn btn btn-save btn-primary d-flex align-items-center" style="font-size: 28px;">
                        <?php echo e(__('dash.addmembership')); ?>

                    </a>
                <?php endif; ?>

                <button type="submit" class="contact-us-btn btn btn-save btn-primary d-flex align-items-center"
                    style="font-size: 28px;">
                    <?php echo e(__('dash.submit')); ?>

                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userarea.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alwaseetlinebh/public_html/resources/views/userarea/profile.blade.php ENDPATH**/ ?>