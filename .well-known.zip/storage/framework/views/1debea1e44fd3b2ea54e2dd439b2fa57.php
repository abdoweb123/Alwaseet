<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['date']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['date']); ?>
<?php foreach (array_filter((['date']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<span class="bg-primary-300 px-1 rounded"><?php echo e(\Carbon\Carbon::parse($date)->format('Y-m-d')); ?></span>
<span class="bg-primary-200 px-1 rounded"><?php echo e(\Carbon\Carbon::parse($date)->format('h:i A')); ?></span>
<span class="bg-primary-100 px-1 rounded"><?php echo e(\Carbon\Carbon::parse($date)->format('l')); ?></span>

<?php /**PATH /home/alwaseetlinebh/public_html/resources/views/components/fulldate.blade.php ENDPATH**/ ?>