<script>
    window.addEventListener('closeModal', event=> {
       $('#addModal').modal('hide')
       $('#editModal').modal('hide')
       $('#changestatus').modal('hide')
       $('#deleteModal').modal('hide')
    });
</script>
<?php /**PATH /home/alwaseetlinebh/public_html/resources/views/components/closeModal.blade.php ENDPATH**/ ?>