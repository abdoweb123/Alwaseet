<?php $__env->startSection('title'); ?>
    <?php if (isset($component)) { $__componentOriginal2346b0df6470764606bbfc809b6744cd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2346b0df6470764606bbfc809b6744cd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pageTitle','data' => ['current' => ''.e(__('dash.contactus')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pageTitle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['current' => ''.e(__('dash.contactus')).'']); ?>
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['title' => ''.e(__('dash.home')).'','route' => ''.e(route('dashboard.home')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(__('dash.home')).'','route' => ''.e(route('dashboard.home')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => ['title' => ''.e(__('dash.contactus')).'','active' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(__('dash.contactus')).'','active' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $attributes = $__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__attributesOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2)): ?>
<?php $component = $__componentOriginale19f62b34dfe0bfdf95075badcb45bc2; ?>
<?php unset($__componentOriginale19f62b34dfe0bfdf95075badcb45bc2); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2346b0df6470764606bbfc809b6744cd)): ?>
<?php $attributes = $__attributesOriginal2346b0df6470764606bbfc809b6744cd; ?>
<?php unset($__attributesOriginal2346b0df6470764606bbfc809b6744cd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2346b0df6470764606bbfc809b6744cd)): ?>
<?php $component = $__componentOriginal2346b0df6470764606bbfc809b6744cd; ?>
<?php unset($__componentOriginal2346b0df6470764606bbfc809b6744cd); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<div>
    <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => ['pagination' => $contacts,'columns' => ['name', 'email', 'phone', 'subject', 'created_at'],'noCreate' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pagination' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($contacts),'columns' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['name', 'email', 'phone', 'subject', 'created_at']),'noCreate' => true]); ?>
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr Role="row" class="odd">
                <td><?php echo e($contacts->firstItem() + $loop->index); ?></td>
                <td><?php echo e($contact->name); ?></td>
                <td><?php echo e($contact->email); ?></td>
                <td><?php echo e($contact->phone); ?></td>
                <td><?php echo e($contact->subject); ?></td>
                <td>
                    <?php if (isset($component)) { $__componentOriginalfbae9df6c232484619cb408dc0484973 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbae9df6c232484619cb408dc0484973 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.fulldate','data' => ['date' => $contact->created_at]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('fulldate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($contact->created_at)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbae9df6c232484619cb408dc0484973)): ?>
<?php $attributes = $__attributesOriginalfbae9df6c232484619cb408dc0484973; ?>
<?php unset($__attributesOriginalfbae9df6c232484619cb408dc0484973); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbae9df6c232484619cb408dc0484973)): ?>
<?php $component = $__componentOriginalfbae9df6c232484619cb408dc0484973; ?>
<?php unset($__componentOriginalfbae9df6c232484619cb408dc0484973); ?>
<?php endif; ?>
                </td>
                <td>
                    <a wire:click="openShowModal(<?php echo e($contact->id); ?>)" type="button" data-bs-toggle="modal" data-bs-target="#showModal">
                        <i class="text-info lni lni-eye mr-10"></i>
                    </a>
                    <a wire:click="openDeleteModal(<?php echo e($contact->id); ?>)" type="button" data-bs-toggle="modal" data-bs-target="#deleteModal">
                        <i class="text-danger lni lni-trash-can"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card my-4 py-4 rounded-full shadow-sm">
            <div class="card-body  text-center">
                <h4><?php echo e(__('dash.nodata')); ?></h4>
            </div>
        </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>


    
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['wireAction' => 'delete','id' => 'deleteModal','title' => ''.e(__('dash.delete')).'','type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wireAction' => 'delete','id' => 'deleteModal','title' => ''.e(__('dash.delete')).'','type' => 'danger']); ?>
        <div class="row">
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'warning']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'warning']); ?>
                <h3><?php echo e(__('dash.alert_delete_confirm')); ?></h3>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['size' => 'modal-lg','id' => 'showModal','title' => ''.e(__('dash.show')).'','type' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'modal-lg','id' => 'showModal','title' => ''.e(__('dash.show')).'','type' => 'danger']); ?>
            <div class="row">
                <table class="table table-bordered">
                    <tbody>
                        <?php if (isset($component)) { $__componentOriginalaa43f035a51007f01bb4e8e5acef6b14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.showitem','data' => ['name' => ''.e(__('dash.created_at')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('showitem'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e(__('dash.created_at')).'']); ?>
                            <?php if (isset($component)) { $__componentOriginalfbae9df6c232484619cb408dc0484973 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbae9df6c232484619cb408dc0484973 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.fulldate','data' => ['date' => $created_at]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('fulldate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($created_at)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbae9df6c232484619cb408dc0484973)): ?>
<?php $attributes = $__attributesOriginalfbae9df6c232484619cb408dc0484973; ?>
<?php unset($__attributesOriginalfbae9df6c232484619cb408dc0484973); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbae9df6c232484619cb408dc0484973)): ?>
<?php $component = $__componentOriginalfbae9df6c232484619cb408dc0484973; ?>
<?php unset($__componentOriginalfbae9df6c232484619cb408dc0484973); ?>
<?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14)): ?>
<?php $attributes = $__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14; ?>
<?php unset($__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa43f035a51007f01bb4e8e5acef6b14)): ?>
<?php $component = $__componentOriginalaa43f035a51007f01bb4e8e5acef6b14; ?>
<?php unset($__componentOriginalaa43f035a51007f01bb4e8e5acef6b14); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalaa43f035a51007f01bb4e8e5acef6b14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.showitem','data' => ['name' => ''.e(__('dash.name')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('showitem'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e(__('dash.name')).'']); ?><?php echo e($name); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14)): ?>
<?php $attributes = $__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14; ?>
<?php unset($__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa43f035a51007f01bb4e8e5acef6b14)): ?>
<?php $component = $__componentOriginalaa43f035a51007f01bb4e8e5acef6b14; ?>
<?php unset($__componentOriginalaa43f035a51007f01bb4e8e5acef6b14); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalaa43f035a51007f01bb4e8e5acef6b14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.showitem','data' => ['name' => ''.e(__('dash.email')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('showitem'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e(__('dash.email')).'']); ?><?php echo e($email); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14)): ?>
<?php $attributes = $__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14; ?>
<?php unset($__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa43f035a51007f01bb4e8e5acef6b14)): ?>
<?php $component = $__componentOriginalaa43f035a51007f01bb4e8e5acef6b14; ?>
<?php unset($__componentOriginalaa43f035a51007f01bb4e8e5acef6b14); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalaa43f035a51007f01bb4e8e5acef6b14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.showitem','data' => ['name' => ''.e(__('dash.subject')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('showitem'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e(__('dash.subject')).'']); ?><?php echo e($subject); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14)): ?>
<?php $attributes = $__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14; ?>
<?php unset($__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa43f035a51007f01bb4e8e5acef6b14)): ?>
<?php $component = $__componentOriginalaa43f035a51007f01bb4e8e5acef6b14; ?>
<?php unset($__componentOriginalaa43f035a51007f01bb4e8e5acef6b14); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalaa43f035a51007f01bb4e8e5acef6b14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.showitem','data' => ['name' => ''.e(__('dash.message')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('showitem'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e(__('dash.message')).'']); ?><?php echo e($message); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14)): ?>
<?php $attributes = $__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14; ?>
<?php unset($__attributesOriginalaa43f035a51007f01bb4e8e5acef6b14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa43f035a51007f01bb4e8e5acef6b14)): ?>
<?php $component = $__componentOriginalaa43f035a51007f01bb4e8e5acef6b14; ?>
<?php unset($__componentOriginalaa43f035a51007f01bb4e8e5acef6b14); ?>
<?php endif; ?>
                    </tbody>
                </table>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    
</div>

<?php $__env->startSection('js'); ?>
<?php if (isset($component)) { $__componentOriginal44a3e282bfe5328496fe85aa27e55030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal44a3e282bfe5328496fe85aa27e55030 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.closeModal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('closeModal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal44a3e282bfe5328496fe85aa27e55030)): ?>
<?php $attributes = $__attributesOriginal44a3e282bfe5328496fe85aa27e55030; ?>
<?php unset($__attributesOriginal44a3e282bfe5328496fe85aa27e55030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal44a3e282bfe5328496fe85aa27e55030)): ?>
<?php $component = $__componentOriginal44a3e282bfe5328496fe85aa27e55030; ?>
<?php unset($__componentOriginal44a3e282bfe5328496fe85aa27e55030); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/alwaseetlinebh/public_html/resources/views/livewire/contact-live.blade.php ENDPATH**/ ?>