<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'data',
    'total'=>false,
    'walletTotla'=>false,
    'columns' => [],
    'pagination' => false,
    'searchable' => false,
    'noCreate' => false,
    'deleteAll' => false,
    'createPage' => null,
    'noAction' => false,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'data',
    'total'=>false,
    'walletTotla'=>false,
    'columns' => [],
    'pagination' => false,
    'searchable' => false,
    'noCreate' => false,
    'deleteAll' => false,
    'createPage' => null,
    'noAction' => false,
]); ?>
<?php foreach (array_filter(([
    'data',
    'total'=>false,
    'walletTotla'=>false,
    'columns' => [],
    'pagination' => false,
    'searchable' => false,
    'noCreate' => false,
    'deleteAll' => false,
    'createPage' => null,
    'noAction' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!--[if BLOCK]><![endif]--><?php if (! ($noCreate || $createPage)): ?>
    <button type="button" class="btn btn-dark my-3 rounded-3" data-bs-toggle="modal" data-bs-target="#addModal">
        <?php echo e(__('dash.create_new')); ?>

    </button>
<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
<!--[if BLOCK]><![endif]--><?php if($createPage): ?>
    <a href="<?php echo e($createPage); ?>" type="button" class="btn btn-dark my-3 rounded-3">
        <?php echo e(__('dash.create_new')); ?>

    </a>
<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
<!--[if BLOCK]><![endif]--><?php if($deleteAll): ?>
    <button wire:click='deleteAll' type="button" class="btn btn-danger my-3 rounded-3">
        <?php echo e(__('dash.delete_all')); ?>

    </button>
<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
<div class="card-styles mt-4">
    <!--[if BLOCK]><![endif]--><?php if($searchable): ?>
        <input wire:model.live='search' type="text" style="width: 20%;" class="form-control w-20"
            placeholder="<?php echo e(__('dash.searchFor')); ?> <?php echo e($searchable); ?> ..">
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    <div class="table-wrapper table-responsive">
        <table class="table clients-table">
            <thead>
                <tr>
                    <th width="5%">#</th>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th>
                            <?php echo e(__('dash.' . $column)); ?>

                        </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if (! ($noAction)): ?>
                        <th width=10%><?php echo e(__('dash.actions')); ?></th>
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </tr>
                </thead>
                <tbody class="text-center">
                    <?php echo e($slot); ?>

                </tbody>
            </table>
            <!--[if BLOCK]><![endif]--><?php if($pagination): ?>
                <?php echo e($pagination->links()); ?>

            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if($total || $walletTotla): ?>
                <div class="container ">
                    <div class="row">
                        <div class="col-6">
                            <h4 class="p-2  bg-info-600 text-black">
                                <!-- Your content for the left side -->

                                <?php echo e(__('dash.total_membership')); ?> : <?php echo e($total); ?>



                            </h4>
                        </div>
                        <div class="col-6">
                            <h4 class="p-2  bg-info-600 text-black">
                                <!-- Your content for the left side -->

                                <?php echo e(__('dash.totalWalet')); ?> : <?php echo e($walletTotla); ?>



                            </h4>
                        </div>
                    </div>
                </div>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
<?php /**PATH /home/alwaseetlinebh/public_html/resources/views/components/table.blade.php ENDPATH**/ ?>