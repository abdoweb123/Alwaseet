<?php

namespace App\Livewire\Dashboard;

use App\Models\Order;
use Livewire\Component;
use Livewire\WithPagination;
use Jantinnerezo\LivewireAlert\LivewireAlert;

class OrderLive extends Component
{
    use WithPagination, LivewireAlert;
    protected $paginationTheme = 'bootstrap';

    public $order_id;
    public $search;

    public $order_number;

    public $bla_name;
    public $id_type;
    public $id_number;
    public $note;
    public $request_status;
    public function openDeleteModal($order_id)
    {
        $this->order_id = $order_id;
    }

    public function delete()
    {
        $order = Order::find($this->order_id);
        if ($order) {
            $order->delete();
            $this->dispatch('closeModal');
            $this->alert('success', __('dash.alert_delete'));
        }
    }

    public function changeStatus($order_id)
    {
        $order = Order::find($order_id);
        $order->status = !$order->status;
        $order->save();
    }

    public function openEditModal($order_id)
    {
        $this->order_id = $order_id;
        $order = Order::find($order_id);
        // dd($order->request_status);
        $this->order_number = $order->order_number;
        $this->bla_name = $order->bla_name;
        $this->id_type = $order->id_type;
        $this->id_number = $order->id_number;
        $this->note = $order->note;
    }
    public function openChangeRequestStatusModal($order_id)
    {
        $this->order_id = $order_id;
        $order = Order::find($order_id);
        $this->request_status = $order->request_status;

    }
    public function updateStatus()
    {

        $this->validate([
            'request_status' => 'required'
        ]);
        // dd($this->request_status);
        $order = Order::find($this->order_id);
        $order->request_status = $this->request_status;
        $order->save();

        $this->dispatch('closeModal');
        $this->alert('success', __('dash.alert_update'));
    }
    public function update()
    {
        $this->validate([
            'note' => 'max:255'
        ]);
        // dd($this->request_status);
        $order = Order::find($this->order_id);
        $order->order_number = $this->order_number;
        $order->bla_name = $this->bla_name;
        $order->id_type = $this->id_type;
        $order->id_number = $this->id_number;
        $order->note = $this->note;
        $order->save();

        $this->dispatch('closeModal');
        $this->alert('success', __('dash.alert_update'));
    }

    public function render()
    {
        $ordersDetailsData = Order::with(['user'])->where('created_at', 'LIKE', '%' . $this->search . '%')
            ->orWhere('name', 'LIKE', '%' . $this->search . '%')
            ->orWhere('phone', 'LIKE', '%' . $this->search . '%')
            ->orWhere('price', 'LIKE', '%' . $this->search . '%')
            ->orWhere('order_number', 'LIKE', '%' . $this->search . '%')
            ->orWhereHas('service', function ($q) {
                $q->where('title_en', 'LIKE', '%' . $this->search . '%')
                    ->orWhere('title_ar', 'LIKE', '%' . $this->search . '%');
            })
            ->latest()->paginate(50);
        $orders = (clone $ordersDetailsData);
        $ordersCount = $ordersDetailsData->count();
        // dd($ordersCount);
        $sumPrice = round((clone $ordersDetailsData)->sum('price'), 3);
        // dd($sumPrice);
        return view('livewire.dashboard.order-live', compact('orders', 'sumPrice', 'ordersCount'));
    }
}
