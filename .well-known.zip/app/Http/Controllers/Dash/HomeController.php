<?php

namespace App\Http\Controllers\Dash;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Company;
use App\Models\CompanyEmail;
use App\Models\Contactus;
use App\Models\Hospital;
use App\Models\Image;
use App\Models\Order;
use App\Models\User;
use App\Models\Product;
use App\Models\Project;
use App\Models\Service;
use App\Models\Specialty;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $home = [
            // 'hospitals' => Hospital::count(),
            // 'services' => Service::count(),
            // 'specialties' => Specialty::count(),
            // 'categories' => Category::count(),
            // 'partners' => Company::count(),
            // 'emails' => CompanyEmail::count(),
        ];

        return view('admin.index', compact('home'));
    }

    public function new_order()
    {
        $users = User::get();
        $services = Service::get();
        return view('admin.new_order', compact('users','services'));
    }
     public function user_data(Request $request)
    {
        // dd(1);
        $user = User::where('id',$request->user_id)->first();
        return response()->json($user);

    }
        public function service_price(Request $request)
    {
        // dd(1);
        $service=Service::find($request->service_id);
        $user = User::where('id',$request->user_id)->first();
        if($user->end_memebership==null){
            $price=$service->price;
        }else{
            $price=$service->price_for_users;
        }
        return response()->json($price);

    }
    
    public function create_order(Request $request)
    {
        
        $request->validate([
            'user_id' => 'required',
        ]);
        // dd($request->all());
        $lastOrder = Order::latest('order_number')->first();
        $nextNumber = $lastOrder ? (int) substr($lastOrder->order_number, 1) + 1 : 1;
        
        $order = new Order();
        $order->order_number = 'R' . str_pad($nextNumber, 6, '0', STR_PAD_LEFT);
        $order->name = $request->name;
        $order->phone = $request->phone;
        $order->service_id = $request->service_id;
        $order->user_id = $request->user_id;
        $order->price = $request->price;
        $order->save();
        
        return redirect(route('dashboard.home'))->with('success', __('dash.item_added'));
    }

    public function show_order($order_id)
    {
        $order = Order::findOrFail($order_id);

        return view('admin.show_order', compact('order'));
    }
}
