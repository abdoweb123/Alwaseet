<script>
    window.addEventListener('closeModal', event=> {
       $('#addModal').modal('hide')
       $('#editModal').modal('hide')
       $('#changestatus').modal('hide')
       $('#deleteModal').modal('hide')
    });
</script>
