<td>{{ ($current_page - 1) * $per_page + $loop->iteration }}</td>
